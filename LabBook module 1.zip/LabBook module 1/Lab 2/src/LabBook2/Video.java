package LabBook2;

public class Video {

}
