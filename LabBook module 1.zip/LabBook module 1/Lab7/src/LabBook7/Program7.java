package LabBook7;

import java.util.*;
public class Program7 {
int[] getSorted(int a[])
{
	int b[]=new int[a.length];
	for(int i=0;i<a.length;i++)
	{
		String a1=Integer.toString(a[i]);
		StringBuffer ab=new StringBuffer(a1);
		b[i]=Integer.parseInt(ab.reverse().toString());
		
	}
	List<Integer> k=new ArrayList<Integer>();
	for(int i=0;i<a.length;i++)
	{
		k.add(b[i]);
	}
	Collections.sort(k);
int arr[]=new int[a.length];
for(int i=0;i<a.length;i++)
{
	arr[i]=k.get(i);
}
return arr;
}
	public static void main(String[] args) {
		Program7 p7=new Program7();
		int a[]=new int[5];
		
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();

		}
	int arr[]=p7.getSorted(a);
		System.out.println(Arrays.toString(arr));
		}
	}

