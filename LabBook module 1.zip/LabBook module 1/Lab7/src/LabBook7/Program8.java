package LabBook7;

import java.util.*;
public class Program8 {
int[] modifyArray(int[] a)
{
	List<Integer> k=new ArrayList<Integer>();
	for(int i=0;i<a.length;i++)
	{
		k.add((Integer)a[i]);
	}
	Set<Integer> s=new HashSet<Integer>(k);
	List<Integer> list=new ArrayList<Integer>(s);
	Collections.sort(list);
	
	int b[]=new int[list.size()];
	int j=0;
	for(int i=list.size()-1;i>=0;i--)
	{
		b[j]=(Integer)list.get(i);
		j++;
	}
	return b;
}
	public static void main(String[] args) {
		Program8 p=new Program8();
		int a[]=new int[5];
		int arr[]=new int[a.length];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();

		}
		arr=p.modifyArray(a);
		System.out.println(Arrays.toString(arr));
		}
	}




