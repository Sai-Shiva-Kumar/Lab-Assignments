package LabBook4;
import java.util.Scanner;
public class Lab4operators{
    public static void main(String[] args) {
    	System.out.println("type a number please: ");
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		int sum=0;
		while(number!=0) {
			int digit=number%10;
			sum=sum+digit*digit*digit;
			number=number/10;
		}
		System.out.println("The sum of digts of given n digit number is "+sum);
}}
