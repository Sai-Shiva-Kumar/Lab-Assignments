package LabBook5;

import java.util.Scanner;
public class Program2 {	
	void fib(int n)
	{	int i;
		int t1=1;int t2=1;
		int t3;
		System.out.println(t1);
		System.out.println(t2);
		for(i=0;i<n;i++)
		{t3=t1+t2;
		t1=t2;
		t2=t3;
		System.out.println(t3);
		}		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Program2 ew=new Program2();
		ew.fib(n);
	}
}
