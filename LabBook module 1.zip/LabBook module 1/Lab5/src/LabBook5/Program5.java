package LabBook5;
import java.util.Scanner;
class InvalidAgeException extends Throwable{
	public InvalidAgeException(String errorMsg) {
		super(errorMsg);
		}
}
public class Program5 {
	static void validation(int Age) throws InvalidAgeException{
		if(Age<15) {
			throw new InvalidAgeException("age should be more than 15");
		}
		else
			System.out.println("Age is above 15");
	}
	public static void main(String args[]) throws InvalidAgeException{
		Scanner sc=new Scanner(System.in);
		Program5 p5=new Program5();
		System.out.println("enter the age");
		int a=sc.nextInt();
		Program5.validation(a);
	}

}
