package LabBook5;

import java.util.Scanner;
public class Program3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int temp=0;
int p;

Scanner sc=new Scanner(System.in);
System.out.println("enter any num:");
int n=sc.nextInt();
sc.close();
for(int j=2;j<n;j++)
{	p=0;
	for(int i=2;i<j;i++)
	{
		temp=j%i;
		if(temp==0){
			p=1;
			
		}
	}
	if(p==0)
	System.out.println(j);
	
}
	}
}