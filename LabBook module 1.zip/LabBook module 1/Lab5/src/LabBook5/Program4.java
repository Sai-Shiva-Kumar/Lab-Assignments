package LabBook5;
class InvalidFullNameException extends Throwable{
	public InvalidFullNameException(String errorMsg) {
		super(errorMsg);
	}
}
public class Program4 {
 static void validation(String FirstName, String LastName) throws  InvalidFullNameException{
	 if((FirstName.equals("John"))&&(LastName.equals("Andrews"))){
		 System.out.println("Credentials verified");
	 }
	 else {
		 throw new InvalidFullNameException("enter valid first and last name");
 }
}
 public static void main(String args[]) throws InvalidFullNameException{
	 Program4 p=new Program4();
	 String FirstName=" ";
	 String LastName=" ";
	 Program4.validation(FirstName,LastName);
 }
}