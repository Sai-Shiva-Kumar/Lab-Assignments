package com.cg.eis.exception;
class InvalidEmpSalaryException extends Throwable{
	public InvalidEmpSalaryException(String errorMsg) {
		super(errorMsg);
	}
}
public class Program6{
	static void validation(int Salary) throws InvalidEmpSalaryException{
		if(Salary>=3000) {
			System.out.println("Employee salary is equal to or above 3000 ");
			
		}
		else
			throw new InvalidEmpSalaryException("Employee salary is below 3000");
	}
	public static void main(String args[]) throws InvalidEmpSalaryException{
		Program6 p6=new Program6();
		int Salary=2500;
		Program6.validation(Salary);
	}

}
