import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
  class CopyDataThread extends Thread{
public CopyDataThread(FileInputStream f1,FileOutputStream f2) throws IOException,InterruptedException{
int l=0,c=0;
while((l=f1.read())!=-1)
{
	System.out.println((char)l);
	f2.write((char)l);
	c=c+1;
	if(c==10)
	{
		System.out.println("10 characters are copied");
		Thread.sleep(5);
		c=0;
	}
}
}
}