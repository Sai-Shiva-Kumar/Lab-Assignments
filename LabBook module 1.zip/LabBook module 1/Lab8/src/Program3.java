
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Program3 {

	public static void main(String[] args) throws IOException,InterruptedException
	{
		FileInputStream f1=null;
		f1=new FileInputStream("D:\\New Text Document.txt");
		FileOutputStream f2=null;
		f2=new FileOutputStream("D:\\New Text Document (2).txt");
		CopyDataThread o=new CopyDataThread(f1,f2);
	}
}