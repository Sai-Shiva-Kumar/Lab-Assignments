package LabBook6;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
class Program2 {
	public static void main(String args[]) throws IOException {
		int z=1;
		char ch;
		Scanner sc=new Scanner(System.in);
		System.out.println("\nplease enter the name: ");
		String str=sc.next();
		FileInputStream out =new FileInputStream(str);
		System.out.println("\ncontents of the file ARE");
	    int  n=(out).available();
		System.out.print(z+": ");
		for(int i=0;i<n;i++) {
			ch=(char)out.read();
			System.out.print(ch);
			if(ch==' ') {
				System.out.print(++z+": ");
			}
		}
	}

}
