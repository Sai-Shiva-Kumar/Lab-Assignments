package LabBook6;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Program1 {
	//Program to write integers and display them individually and display the sum of the integers
	public static void main(String[] args) {
		int n,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter integers:");
        String s=sc.nextLine();
        StringTokenizer st=new StringTokenizer(s," ");
        while(st.hasMoreTokens()) {
        	String s1=st.nextToken();
        	n=Integer.parseInt(s1);
        	System.out.println(n);
        	sum=sum+n;
        }
       	 System.out.println("the sum of given range of integers is " +sum);
	}

}
