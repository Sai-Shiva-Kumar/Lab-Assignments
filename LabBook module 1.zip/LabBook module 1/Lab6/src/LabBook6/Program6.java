package LabBook6;

import java.io.*;
class Program6
{
	public static void main(String args[])
	{
		try
		{
			int nooflines=0,noofchars=0,noofwords=0;
			int c=0;
			FileInputStream fis = new FileInputStream("C:\\Users\\SAISHIVA\\Desktop\\java\\s1.txt");
			while(fis.available()!=0)
			{
				c = fis.read();
				if(c!=10)
				noofchars++;
				if(c==32)
				noofwords++;
				if(c==13)
				{
					nooflines++;
					noofwords++;
				}
			}
			System.out.println("No.of characters = "+noofchars);
			System.out.println("No.of words = "+(noofwords+1));
			System.out.println("No.of lines = "+(nooflines+1));
			fis.close();
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Cannot find the specified file...");
		}
		catch(IOException i)
		{
			System.out.println("Cannot read file...");
		}
	}
}