package LabBook6;
class Program4
{ 
	static boolean Vowel(char ch) 
	{ 
		if (ch != 'a' && ch != 'e' && ch != 'i'
				&& ch != 'o' && ch != 'u') 
		{ 
			return false; 
		} 
		return true; 
	} 
	static String alterString(char[] s) 
	{ 
		for (int i = 0; i < s.length; i++) 
		{ 
			if (!Vowel(s[i])) 
			{ 

				if (s[i] == 'z') 
				{ 
					s[i] = 'b'; 
				} 
				else
				{ 
					s[i] = (char) (s[i] + 1); 
					if (Vowel(s[i])) 
					{ 
						s[i] = (char) (s[i]); 
					} 
				} 
			} 
		} 
		return String.valueOf(s); 
	}
	public static void main(String[] args) 
	{ 
		String s = "java"; 
		System.out.println(alterString(s.toCharArray())); 
	} 
} 


