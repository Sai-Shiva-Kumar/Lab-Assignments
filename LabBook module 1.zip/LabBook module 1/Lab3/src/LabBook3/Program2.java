package LabBook3;

import java.util.Arrays;
import java.util.Scanner;

public class Program2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		System.out.println(s);
	    int n=s.length();
	    System.out.println(n);
	    String s1,s2,s3,s4,s5;
		if(n%2==0){
			s1=s.substring(0, n/2);
		    s2=s.substring(n/2, n);
		    s3=s1.toUpperCase();
		    s4=s2.toLowerCase();
		    s5=s3.concat(s4);
		    System.out.println(s3);
		}
		else{
			s1=s.substring(0, (n+1)/2);
	        s2=s.substring((n+1)/2, n);
	        s4=s1.toUpperCase();
	        s5=s2.toLowerCase();
	        s3=s4.concat(s5);
	        System.out.println(s3);
		}
	}
}