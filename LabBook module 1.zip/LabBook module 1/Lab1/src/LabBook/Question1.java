package LabBook;
import java.util.Scanner;
public class Question1 {
	//Calculate Sum of first n natural numbers divisible by 3 or 5//
	public int calculateSum(int n) {
		int i,sum=0;
		for(i=1;i<=n;i++) {
			if((i%3==0)||(i%5==0)){
				sum+=i;
			}
		}
		return sum;
		}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        Question1 c=new Question1();
        int sum=c.calculateSum(n);
        System.out.println("Sum of the first n natural numbers divisible by 3 or 5 is "+sum);
		
	}

}
