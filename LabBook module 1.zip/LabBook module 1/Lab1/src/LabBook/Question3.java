package LabBook;
import java.util.Scanner;
public class Question3 {
	//to check whether given number is increasing or not
	boolean checkNum(int number) {
		boolean f=false;
		while(number>0) {
			int cd=number%10;
			number=number/10;
			if(cd>=number%10)
				f=true;
			else {
				f=false;
				break;
			}
		}
		return f;
	}
	public static void main(String[] args) {
		Scanner n=new Scanner(System.in);
		int number=n.nextInt();
		Question3 z=new Question3();
		System.out.println(z.checkNum(number));
			}
}