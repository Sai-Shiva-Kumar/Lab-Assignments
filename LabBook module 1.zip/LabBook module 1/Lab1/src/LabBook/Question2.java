package LabBook;
import java.util.Scanner;
public class Question2{
	public int calculateDifference(int n) {
		//calculate the difference between sum of squares and sqare of sum of first n natural numbers//
         int sum;
         int a,b;
         a= (n*(n+1)*((2*n)+1))/6;
         b= ((n*(n+1))*(n*(n+1)))/4;
         return sum=a-b;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
	    Question2 d=new Question2();
		int sum=d.calculateDifference(n);
		System.out.println("the difference between sum of the squares and square of the sum of first n natural numbers is "+sum);
	}
}