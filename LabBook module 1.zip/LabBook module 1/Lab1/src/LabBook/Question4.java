package LabBook;
import java.util.Scanner;
public class Question4 {
boolean checkNumber(int n) {
	//to check if a number is a power of two or not
	boolean b=false;
	while(n!=1) {
		if(n%2==0) {
			n=n/2;
			b=true;
		}
		else
		{
			b=false;
			break;
		}
	}
return b;
}
 public static void main(String[] args) {
	Scanner powcheck =new Scanner(System.in);
	int n=powcheck.nextInt();
	Question4 p = new Question4();
	boolean b=p.checkNumber(n);
	System.out.println(b);
}
	
}
