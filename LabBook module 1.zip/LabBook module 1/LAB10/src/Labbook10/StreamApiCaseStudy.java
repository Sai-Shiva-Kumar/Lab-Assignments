package Labbook10;

import java.time.LocalDate;
import java.time.Period;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
interface fn{
	String fn(); 
}
interface dc{
	String dc(); 
}
class Employee{
	int employeeId,managerId;
	double salary;
	String firstName,lastName,email,phoneNumber,designation;
	LocalDate hireDate;
	Department department;
	public Employee(int employeeId, int managerId, double salary, String firstName, String lastName, String email,
			String phoneNumber, String designation, LocalDate hireDate, Department department) {
		super();
		this.employeeId = employeeId;
		this.managerId = managerId;
		this.salary = salary;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.designation = designation;
		this.hireDate = hireDate;
		this.department = department;
	}
	
	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}

class Department{
	int departmentId,managerId;
	String departmentName;
	public Department(int departmentId, int managerId, String departmentName) {
		super();
		this.departmentId = departmentId;
		this.managerId = managerId;
		this.departmentName = departmentName;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public int getManagerId() {
		return managerId;
	}
	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
}

public class StreamApiCaseStudy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Department> d=new ArrayList<Department>();
		d.add(new Department(100,1,"HR"));
		d.add(new Department(101,2,"Management"));
		d.add(new Department(102,3,"Marketing"));
		d.add(new Department(103,4,"Development"));
		d.add(new Department(104,5,"Maintainance"));
		/*Department d1=new Department(100,1,"HR");
		Department d2=new Department(101,2,"Management");
		Department d3=new Department(102,3,"Marketing");
		Department d4=new Department(103,4,"Development");
		Department d5=new Department(104,5,"Maintainance");*/
		
		List<Employee> e=new ArrayList<Employee>();
		e.add(new Employee(502,1,45000,"Jackie","Chan","jc@gmail.com","123412","hyderabd",LocalDate.of(2019,11,25),new Department(100,1,"HR")));
		e.add(new Employee(501,1,50000,"Tom","Cruise","tc@gmail.com","893412","hyderabad",LocalDate.of(2019,11,10),new Department(100,1,"HR")));
		e.add(new Employee(503,4,70000,"Keemu","Reeves","kr@gmail.com","123412","bangalore",LocalDate.of(2019,11,25),new Department(103,4,"Development")));
		e.add(new Employee(505,3,55000,"Christian","Bale","cb@gmail.com","123412","goa",LocalDate.of(2018,2,20),null));
		e.add(new Employee(504,0,10000,"Robert","Downey","rd@gmail.com","123412","mumbai",LocalDate.of(2019,12,25),null));
		
		
		//Find out the sum of salary of all employees
		double sal=e.stream().collect(Collectors.summingDouble(Employee::getSalary));
		System.out.println("Sum of Salary : "+sal);
		
		//Find out employees without department. 
		e.stream().filter(dp->dp.department==null).forEach(dp->System.out.println("employees without department : "+dp.employeeId+" "+dp.firstName));
		
		//List employee name, salary and salary increased by 15%
		System.out.println("Employee name, salary and salary increased by 15% :");
		e.stream().filter(w->w.firstName!=null).forEach(w->System.out.println(w.firstName+" "+w.lastName+"-Salary: "+w.salary+" After increment : "+w.salary*1.15));
		
		//List employee�s names and name of manager to whom he/she reports. Create a report in format �employee name reports to manager name�. 
		System.out.println("Reports :");
		e.stream().filter(q->q.managerId!=0).forEach(q->System.out.println(q.firstName+" "+q.lastName+" reports to "+q.managerId));
		
		//Find employees who didn�t report to anyone (Hint: Employees without manager) 
		e.stream().filter(m->m.managerId==0).forEach(m->System.out.println("employees who didn�t report to anyone : "+m.employeeId+" "+m.firstName));
	}

	private static Collector groupingBy(Object object) {
		// TODO Auto-generated method stub
		return null;
	}

}